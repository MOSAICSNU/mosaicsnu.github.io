---
name: Bug report
about: Report an installation, analysis, or export problem
title: ''
labels: bug
assignees: ''
---

MOSAIC version:
Operating system / Python version:
ND2 dimensions and bit depth:
Pacing interval / Peak cutoff / Tran. range:
Photobleaching settings:

Steps to reproduce:
Expected result:
Observed result and Status message:

Attach a small shareable example or screenshot if useful. Remove personal
paths and confidential information before posting.
